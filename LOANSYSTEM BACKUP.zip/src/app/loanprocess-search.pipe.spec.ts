import { LoanprocessSearchPipe } from './loanprocess-search.pipe';

describe('LoanprocessSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new LoanprocessSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
