import { LoanplanSearchPipe } from './loanplan-search.pipe';

describe('LoanplanSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new LoanplanSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
