import { CustomerSearchPipe } from './customer-search.pipe';

describe('CustomerSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new CustomerSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
