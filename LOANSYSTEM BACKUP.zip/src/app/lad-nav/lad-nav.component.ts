import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lad-nav',
  templateUrl: './lad-nav.component.html',
  styleUrls: ['./lad-nav.component.css']
})
export class LadNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
