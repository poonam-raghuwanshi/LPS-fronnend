import { LoanSearchPipe } from './loan-search.pipe';

describe('LoanSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new LoanSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
