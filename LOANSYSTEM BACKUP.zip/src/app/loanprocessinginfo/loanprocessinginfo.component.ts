import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanprocessinginfo',
  templateUrl: './loanprocessinginfo.component.html',
  styleUrls: ['./loanprocessinginfo.component.css']
})
export class LoanprocessinginfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
